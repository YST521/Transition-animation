//
//  WaveTableViewCell.h
//  LXWaveProgressDemo
//
//  Created by liuxin on 16/8/1.
//  Copyright © 2016年 liuxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LXWaveProgressView;
@interface WaveTableViewCell : UITableViewCell

@property (nonatomic,strong)LXWaveProgressView *progressView;

@end
