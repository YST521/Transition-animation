//
//  AppDelegate.h
//  ZBPercentWaterView
//
//  Created by xzb on 2016/12/29.
//  Copyright © 2016年 xzb. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

