//
//  UIView+Shape.h
//  XZBAppTest
//
//  Created by xzb on 2016/11/9.
//  Copyright © 2016年 xzb. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import <UIKit/UIKit.h>

@interface UIView (Shape)

- (void)setShape:(CGPathRef)shape;

@end
