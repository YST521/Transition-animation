//
//  AddAddressTableViewCell.h
//  AiMeiBang
//
//  Created by Lingxiu on 16/2/23.
//  Copyright © 2016年 zym. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddAddressTableViewCell : UITableViewCell

+ (instancetype)cellWithTableView:(UITableView *)tableView;
@end
