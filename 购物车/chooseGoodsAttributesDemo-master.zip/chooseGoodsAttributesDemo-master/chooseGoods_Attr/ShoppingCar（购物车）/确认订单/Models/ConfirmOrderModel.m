//
//  ConfirmOrderModel.m
//  AiMeiBang
//
//  Created by Lingxiu on 16/2/26.
//  Copyright © 2016年 zym. All rights reserved.
//

#import "ConfirmOrderModel.h"

@implementation ConfirmOrderModel

@end
