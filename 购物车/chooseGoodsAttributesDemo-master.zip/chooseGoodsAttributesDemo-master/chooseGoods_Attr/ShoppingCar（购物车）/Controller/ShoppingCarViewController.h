//
//  ShoppingCarViewController.h
//  AiMeiBang
//
//  Created by Lingxiu on 16/1/27.
//  Copyright © 2016年 zym. All rights reserved.
//

#import "BaseStatusBarViewController.h"

@interface ShoppingCarViewController : BaseStatusBarViewController

@end
