//
//  BuyCarModel.m
//  AiMeiBang
//
//  Created by Lingxiu on 16/2/24.
//  Copyright © 2016年 zym. All rights reserved.
//

#import "BuyCarModel.h"

@implementation BuyCarModel

@end
