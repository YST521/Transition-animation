//
//  ShoppingCarCellModel.h
//  AiMeiBang
//
//  Created by Lingxiu on 16/2/1.
//  Copyright © 2016年 zym. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ShoppingCarCellModel : NSObject

@property (nonatomic, assign) BOOL isSelected;
@end
