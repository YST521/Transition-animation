//
//  ShoppingCarCellModel.m
//  AiMeiBang
//
//  Created by Lingxiu on 16/2/1.
//  Copyright © 2016年 zym. All rights reserved.
//

#import "ShoppingCarCellModel.h"

@implementation ShoppingCarCellModel

@end
