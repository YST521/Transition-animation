//
//  PaySuccessViewController.h
//  AiMeiBang
//
//  Created by Lingxiu on 16/3/9.
//  Copyright © 2016年 zym. All rights reserved.
//

#import "BaseStatusBarViewController.h"

@interface PaySuccessViewController : BaseStatusBarViewController

@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *shop_price;
@property (nonatomic, copy) NSString *fromStr;
@end
