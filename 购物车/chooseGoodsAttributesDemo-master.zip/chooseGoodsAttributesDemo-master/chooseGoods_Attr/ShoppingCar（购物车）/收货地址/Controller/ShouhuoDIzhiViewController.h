//
//  ShouhuoDIzhiViewController.h
//  AiMeiBang
//
//  Created by Lingxiu on 16/1/25.
//  Copyright © 2016年 zym. All rights reserved.
//

#import "BaseStatusBarViewController.h"

@interface ShouhuoDIzhiViewController : BaseStatusBarViewController

@property (nonatomic, strong) NSArray *addressArr;
@property (weak, nonatomic) IBOutlet UIButton *bottomBtn;
@end
