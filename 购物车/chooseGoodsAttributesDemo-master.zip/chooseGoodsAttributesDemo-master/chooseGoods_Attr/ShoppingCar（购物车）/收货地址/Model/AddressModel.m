//
//  AddressModel.m
//  AiMeiBang
//
//  Created by Lingxiu on 16/2/22.
//  Copyright © 2016年 zym. All rights reserved.
//

#import "AddressModel.h"

@implementation AddressModel

@end
