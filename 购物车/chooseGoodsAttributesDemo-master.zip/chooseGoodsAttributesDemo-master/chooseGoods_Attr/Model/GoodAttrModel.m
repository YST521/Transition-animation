//
//  GoodAttrModel.m
//  AiMeiBang
//
//  Created by Lingxiu on 16/2/21.
//  Copyright © 2016年 zym. All rights reserved.
//

#import "GoodAttrModel.h"

@implementation GoodAttrModel
+ (NSDictionary *)mj_objectClassInArray
{
    return @{
             @"attr_value" : @"GoodAttrValueModel",
             };
}
@end

@implementation GoodAttrValueModel


@end