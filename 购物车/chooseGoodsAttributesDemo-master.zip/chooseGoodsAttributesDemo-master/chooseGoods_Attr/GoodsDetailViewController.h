//
//  GoodsDetailViewController.h
//  chooseGoods_Attr
//
//  Created by Lingxiu on 15/12/21.
//  Copyright © 2015年 Lingxiu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GoodsDetailViewController : UIViewController

@end
