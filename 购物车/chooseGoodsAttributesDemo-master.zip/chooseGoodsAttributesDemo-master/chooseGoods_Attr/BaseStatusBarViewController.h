//
//  BaseStatusBarViewController.h
//  AiMeiBang
//
//  Created by Lingxiu on 16/3/26.
//  Copyright © 2016年 zym. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseStatusBarViewController : UIViewController

@end
