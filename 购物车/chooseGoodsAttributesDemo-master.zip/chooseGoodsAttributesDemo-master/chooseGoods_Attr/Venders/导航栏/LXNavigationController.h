//
//  LXNavigationController.h
//  AiMeiBang
//
//  Created by Lingxiu on 16/1/16.
//  Copyright © 2016年 zym. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LXNavigationController : UINavigationController

@end
