# chooseGoodsAttributesDemo

> 1.实现购买物品属性界面，当前写的程序只能接收两个物品属性。

>本项目是用CocoaPods来进行管理第三方库，所以进入文件夹打开chooseGoods_Attr.xcworkspace文件。

效果图如下：

![物品选择效果图](http://7xq2wz.com1.z0.glb.clouddn.com/%E8%B4%AD%E4%B9%B0%E7%89%A9%E5%93%81%E5%B1%9E%E6%80%A7%E7%95%8C%E9%9D%A2.gif)

> 2.设置购物车按钮角标效果，添加购物车页面，并设置右上角编辑按钮。

![带角标的效果图](http://7xq2wz.com1.z0.glb.clouddn.com/%E6%B7%BB%E5%8A%A0%E8%B4%AD%E7%89%A9%E8%BD%A6%E9%A1%B5%E9%9D%A2.gif)

我很丑，但是我很温柔，- -、

> 3.数据添加之后的效果。

![购物车页面数据展示](http://7xq2wz.com1.z0.glb.clouddn.com/%E8%B4%AD%E7%89%A9%E8%BD%A6%E9%A1%B5%E9%9D%A2%E6%95%B0%E6%8D%AE%E5%B1%95%E7%A4%BA.gif)

> 4.从购物车选择商品之后，进入订单确认页面

![确认订单页面](http://7xq2wz.com1.z0.glb.clouddn.com/%E8%B4%AD%E7%89%A9%E8%BD%A6%E7%A1%AE%E8%AE%A4%E8%AE%A2%E5%8D%95%E9%A1%B5%E9%9D%A2.gif)
